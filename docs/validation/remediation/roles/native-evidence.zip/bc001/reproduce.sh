#!/bin/sh
set -eu
test "$#" -eq 1 || { echo "Usage: sh reproduce.sh NEW_DIRECTORY" >&2; exit 2; }
src=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
mkdir -- "$1"
cd -- "$1"
cp -- "$src"/input_R1.fastq.gz .
printf "%s\n" '6852838095abf7e5f36fb34ec25905da6390f04bf8ed606d42cb76535fc47802  input_R1.fastq.gz' | sha256sum -c -
cp -- "$src"/input_R2.fastq.gz .
printf "%s\n" 'bca29bb060115e9fb4fa4fd7c1eb1e533dd7219fdee97eb65ae0032914c0d43c  input_R2.fastq.gz' | sha256sum -c -
exec docker run --rm --network none --user "$(id -u):$(id -g)" --volume "$PWD:/work" --workdir /work --entrypoint /CRISPResso2/.pixi/envs/default/bin/CRISPResso pinellolab/crispresso2@sha256:b7e7971a87769aa584d31d21e199a9abca5f641c4f889c2e807cb6324fc8ce0c -r1 input_R1.fastq.gz -r2 input_R2.fastq.gz --amplicon_seq TCCTTAGGCGTAAAATGGGCTTCTCACTGATTTTAGGACAGACGTAAATGGTCGCTCGTCATTCTCAATTATCGCCCACCCGACAAGTCGCGGATACTAATCTATAGGCAGTAAGAAGCAACCGGTGCAGAAAATTCGTCACATGTCTCTTTATGCTGTACCTTACCAACGGCTTGAATTGATCGATGCATCCCATCTCGGCTCTCTGACTCCGGGGCAGATCAACCGAGTCTTCACACG --quantification_window_coordinates 104-113 --exclude_bp_from_left 0 --exclude_bp_from_right 0 --name nuclease --output_folder output --write_detailed_allele_table --keep_intermediate
