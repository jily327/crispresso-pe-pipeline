#!/bin/sh
set -eu
test "$#" -eq 1 || { echo "Usage: sh reproduce.sh NEW_DIRECTORY" >&2; exit 2; }
src=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
mkdir -- "$1"
cd -- "$1"
cp -- "$src"/input_R1.fastq.gz .
printf "%s\n" '107acd147022d4d2ee028992c42e803b37b53297a5d1ba0a1c7762a055fd1376  input_R1.fastq.gz' | sha256sum -c -
cp -- "$src"/input_R2.fastq.gz .
printf "%s\n" '2967df806b0e1a87483cca19d5c057f733a8c567c21ace38c17583c01349ba49  input_R2.fastq.gz' | sha256sum -c -
exec docker run --rm --network none --user "$(id -u):$(id -g)" --volume "$PWD:/work" --workdir /work --entrypoint /CRISPResso2/.pixi/envs/default/bin/CRISPResso pinellolab/crispresso2@sha256:b7e7971a87769aa584d31d21e199a9abca5f641c4f889c2e807cb6324fc8ce0c -r1 input_R1.fastq.gz -r2 input_R2.fastq.gz --amplicon_seq TCCTTAGGCGTAAAATGGGCTTCTCACTGATTTTAGGACAGACGTAAATGGTCGCTCGTCATTCTCAATTATCGCCCACCCGACAAGTCGCGGATACTAATCTATAGGCAGTAAGAAGCAACCGGTGCAGAAAATTCGTCACATGTCTCTTTATGCTGTACCTTACCAACGGCTTGAATTGATCGATGCATCCCATCTCGGCTCTCTGACTCCGGGGCAGATCAACCGAGTCTTCACACG --quantification_window_coordinates 104-113 --exclude_bp_from_left 0 --exclude_bp_from_right 0 --name nuclease --output_folder output --write_detailed_allele_table --keep_intermediate
