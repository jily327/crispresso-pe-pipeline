#!/bin/sh
set -eu
test "$#" -eq 1 || { echo "Usage: sh reproduce.sh NEW_DIRECTORY" >&2; exit 2; }
src=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
mkdir -- "$1"
cd -- "$1"
cp -- "$src"/input_R1.fastq.gz .
printf "%s\n" '8f6991d98f29fbd13038cf9534431685dff8cf5c83dbbafb060c49b372ecd8f4  input_R1.fastq.gz' | sha256sum -c -
cp -- "$src"/input_R2.fastq.gz .
printf "%s\n" 'f7ee76461a649eed63257687bcbbd5d4759d7974e95f4ebfc3b712dfea2bb8a0  input_R2.fastq.gz' | sha256sum -c -
exec docker run --rm --network none --user "$(id -u):$(id -g)" --volume "$PWD:/work" --workdir /work --entrypoint /CRISPResso2/.pixi/envs/default/bin/CRISPResso pinellolab/crispresso2@sha256:b7e7971a87769aa584d31d21e199a9abca5f641c4f889c2e807cb6324fc8ce0c -r1 input_R1.fastq.gz -r2 input_R2.fastq.gz --amplicon_seq GACTCCTTAGGCGTAAAATGGGCTTCTCACTGAATTTAGGACAGACGTAAATGGTAGCTCGTCATTCTCAATTATCGACCACCCGACAAGTCGCGGATACTAATCTATAGGCAGTAAGAAGCAACCGGTGCAGAAAATTCGTCACATGTCTCTTTAAGCTGTACCTTACCAACGGCTTGCATTGATCGATGCATCCCATCTCAGCTCTCTGACTCCGGGGCAGATCAACCGAGTCTTCACACG --quantification_window_coordinates 103-120 --exclude_bp_from_left 0 --exclude_bp_from_right 0 --name nuclease --output_folder output --write_detailed_allele_table --keep_intermediate
