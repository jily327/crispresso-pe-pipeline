#!/bin/sh
set -eu
test "$#" -eq 1 || { echo "Usage: sh reproduce.sh NEW_DIRECTORY" >&2; exit 2; }
src=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
mkdir -- "$1"
cd -- "$1"
cp -- "$src"/input_R1.fastq.gz .
printf "%s\n" '873626d3faef8fc7ef9f9d65a58bd249aa291f63df1f1a19728d8e0c9619c466  input_R1.fastq.gz' | sha256sum -c -
cp -- "$src"/input_R2.fastq.gz .
printf "%s\n" '3d2bbe168bbc1d3632058090083392f89c4b6d344d05d6788298914e2494672d  input_R2.fastq.gz' | sha256sum -c -
exec docker run --rm --network none --user "$(id -u):$(id -g)" --volume "$PWD:/work" --workdir /work --entrypoint /CRISPResso2/.pixi/envs/default/bin/CRISPResso pinellolab/crispresso2@sha256:b7e7971a87769aa584d31d21e199a9abca5f641c4f889c2e807cb6324fc8ce0c -r1 input_R1.fastq.gz -r2 input_R2.fastq.gz --amplicon_seq GACTCCTTAGGCGTAAAATGGGCTTCTCACTGAATTTAGGACAGACGTAAATGGTAGCTCGTCATTCTCAATTATCGACCACCCGACAAGTCGCGGATACTAATCTATAGGCAGTAAGAAGCAACCGGTGCAGAAAATTCGTCACATGTCTCTTTAAGCTGTACCTTACCAACGGCTTGCATTGATCGATGCATCCCATCTCAGCTCTCTGACTCCGGGGCAGATCAACCGAGTCTTCACACG --quantification_window_coordinates 107-116 --exclude_bp_from_left 0 --exclude_bp_from_right 0 --name nuclease --output_folder output --write_detailed_allele_table --keep_intermediate
