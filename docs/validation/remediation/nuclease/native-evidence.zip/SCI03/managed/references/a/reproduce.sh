#!/bin/sh
set -eu
test "$#" -eq 1 || { echo "Usage: sh reproduce.sh NEW_DIRECTORY" >&2; exit 2; }
src=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
mkdir -- "$1"
cd -- "$1"
cp -- "$src"/input_R1.fastq.gz .
printf "%s\n" '7789a9a89e6c85083254bc3c835cd8732e89a966147b78f731bfe746aa90fa57  input_R1.fastq.gz' | sha256sum -c -
cp -- "$src"/input_R2.fastq.gz .
printf "%s\n" '8e5f0638a19f7e2492408e2d7fbdf07abb600756904368a0d44ece1fb01c7766  input_R2.fastq.gz' | sha256sum -c -
exec docker run --rm --network none --user "$(id -u):$(id -g)" --volume "$PWD:/work" --workdir /work --entrypoint /CRISPResso2/.pixi/envs/default/bin/CRISPResso pinellolab/crispresso2@sha256:b7e7971a87769aa584d31d21e199a9abca5f641c4f889c2e807cb6324fc8ce0c -r1 input_R1.fastq.gz -r2 input_R2.fastq.gz --amplicon_seq TCCTTAGGCGTAAAATGGGCTTCTCACTGATTTTAGGACAGACGTAAATGGTCGCTCGTCATTCTCAATTATCGCCCACCCGACAAGTCGCGGATACTAATCTATAGGCAGTAAGAAGCAACCGGTGCAGAAAATTCGTCACATGTCTCTTTATGCTGTACCTTACCAACGGCTTGAATTGATCGATGCATCCCATCTCGGCTCTCTGACTCCGGGGCAGATCAACCGAGTCTTCACACG --quantification_window_coordinates 104-113_132-135 --exclude_bp_from_left 0 --exclude_bp_from_right 0 --name nuclease --output_folder output --write_detailed_allele_table --keep_intermediate
